pub mod cxwht {
    pub const MESSAGE: &str = "cxwht";
    pub const URL: &str = "https:cxwht.cn";

    pub fn get_url() {
        println!("{}", URL);
    }
}
